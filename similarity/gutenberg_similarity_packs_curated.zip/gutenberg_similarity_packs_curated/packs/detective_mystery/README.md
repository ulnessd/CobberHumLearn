# Detective / Mystery Stories

Eight detective/mystery texts representing Sherlock Holmes, Arsene Lupin, Poirot, Father Brown, and Wilkie Collins.

Texts in this pack: 8.
