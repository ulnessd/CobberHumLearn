# CobberHumanGNNData

Data package prepared from the uploaded Mapping the Mythos Kaggle files.

## Feature vector

Every node uses the same 18-feature vector:

Divine, Mortal, Monster, Place, Object_Structure, Heroic, Political, Familial, Helper, Opponent, Traveler, Host_Guest, Prophecy_Fate, Underworld_Death, Sea_Water, Domestic_Homecoming, Violence_War, Transformation_Magic

Values are:
- 0 = not central / not indicated
- 1 = present or weakly indicated
- 2 = strongly central

These features are pedagogical interpretations, not scholarly final judgments. They are intended to be editable by students and instructors.

## Files

- `feature_schema.csv` — descriptions of the 18 features.
- `myth_nodes_features_full.csv` — full node table with 18 features.
- `myth_edges_aggregated_full.csv` — full graph edges aggregated by source-target pair.
- `odyssey_edges_raw.csv` — raw Odyssey edge rows from the Kaggle data.
- `odyssey_edges_aggregated.csv` — Odyssey graph aggregated by source-target pair.
- `odyssey_nodes_features_full.csv` — all Odyssey nodes with 18 features.
- `odyssey_teaching_100_nodes_features.csv` — curated 100-node teaching subset.
- `odyssey_teaching_100_edges.csv` — edges among the 100 teaching nodes.
- `odyssey_node_stats.csv` — degree and weighted-degree statistics.

## Counts

- Full feature node table: 1076 nodes.
- Full aggregated edge table: 26696 source-target pairs.
- Odyssey raw edge rows: 977.
- Odyssey unique nodes: 190.
- Odyssey aggregated source-target pairs: 977.
- Odyssey teaching subset: 100 nodes and 721 edges.

## Feature construction method

The full graph uses semi-automatic feature assignment:
1. Rules based on metadata fields such as description, type, level2/level3, residence, aliases, and Theoi links.
2. Keyword triggers for mythic roles such as divine, monster, ruler, prophet, underworld, sea, travel, and magic.
3. Manual overrides for major figures especially relevant to the Theseus and Odyssey teaching graphs.
4. Lower confidence labels remain marked as `rules` or `fallback`.

For teaching use, the Odyssey 100-node subset should be treated as a strong first draft, not as an authoritative classical reference.
